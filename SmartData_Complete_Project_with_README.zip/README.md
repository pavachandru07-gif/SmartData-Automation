# SmartData: Automated Data Cleaning and Reporting System

## 📊 Project Overview

**SmartData** is a beginner-friendly Python application that automates common data-cleaning and reporting tasks.

The application accepts **CSV or Excel files**, cleans the data, handles missing values and duplicate records, and generates useful outputs automatically.

## 🎯 Objectives

- Automate basic data preprocessing
- Remove duplicate records
- Handle missing values
- Standardize column names and text
- Generate a cleaned Excel file
- Create an automated data report
- Generate a visual summary chart

## ✨ Features

- 📁 CSV and Excel file support
- 🧹 Automatic data cleaning
- 🔄 Duplicate record removal
- ❓ Missing-value handling
- ✏️ Column-name standardization
- 📊 Data visualization
- 📄 Automatic report generation
- 🖥️ Simple graphical user interface

## 🛠️ Technologies Used

| Technology | Purpose |
|---|---|
| Python | Main programming language |
| Pandas | Data cleaning and analysis |
| OpenPyXL | Excel file handling |
| Matplotlib | Data visualization |
| Tkinter | Graphical user interface |

## 🔄 How It Works

```text
CSV / Excel File
       ↓
Load Data
       ↓
Remove Empty Rows & Columns
       ↓
Remove Duplicate Records
       ↓
Standardize Data
       ↓
Handle Missing Values
       ↓
Save Cleaned Excel File
       ↓
Generate Report & Chart
```

## 🚀 How to Run

### 1. Install Python

Make sure Python 3 is installed on your computer.

### 2. Install the required libraries

Open Command Prompt or Terminal inside the project folder and run:

```bash
pip install -r requirements.txt
```

### 3. Run the application

```bash
python smartdata.py
```

### 4. Test the project

Select:

```text
sample_data.csv
```

Then click:

**CLEAN DATA & GENERATE REPORT**

## 📂 Project Structure

```text
SmartData-Complete-Project/
│
├── smartdata.py
├── sample_data.csv
├── requirements.txt
├── README.md
├── Project_Report.txt
├── SmartData_Presentation.pptx
│
└── output/
    ├── cleaned_data.xlsx
    ├── data_report.txt
    └── data_summary.png
```

## 📤 Output

After processing a dataset, SmartData generates:

- **cleaned_data.xlsx** — cleaned dataset
- **data_report.txt** — summary of the cleaning process
- **data_summary.png** — visual summary of the data

## 🧪 Sample Dataset

The included `sample_data.csv` contains intentionally messy data with examples of:

- Missing values
- Duplicate records
- Inconsistent capitalization
- Extra spaces

This allows the application to be tested immediately.

## 🌱 Future Enhancements

- Interactive web dashboard
- PDF report generation
- Advanced anomaly detection
- Custom data-cleaning rules
- More chart types
- Streamlit-based web interface

## 🎓 Learning Outcomes

This project demonstrates practical use of:

- Python programming
- File handling
- Data preprocessing
- Pandas
- Excel automation
- Basic statistics
- Data visualization
- GUI development

## 👤 Author

**Pavachandru**

Computer Science & Engineering Student

## 📌 Project Type

Academic / Beginner Python Project

---

⭐ If you find this project useful, feel free to explore and improve it!
