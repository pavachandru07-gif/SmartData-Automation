# SmartData — Complete Project

## Run the project
1. Install Python 3.
2. Open Command Prompt in this folder.
3. Run:
   `pip install -r requirements.txt`
4. Run:
   `python smartdata.py`
5. Choose `sample_data.csv`.
6. Click **CLEAN DATA & GENERATE REPORT**.

## Files
- `smartdata.py` — main application
- `sample_data.csv` — test dataset
- `requirements.txt` — required Python packages
- `Project_Report.txt` — project documentation
- `SmartData_Presentation.pptx` — presentation
- `output/cleaned_data.xlsx` — example cleaned data
- `output/data_report.txt` — example report
- `output/data_summary.png` — example chart

## Project title
**SmartData: Automated Data Cleaning and Reporting System**

## Viva one-line explanation
“SmartData is a Python application that automatically cleans CSV/Excel data, handles missing values and duplicates, and generates a report and visual summary.”
