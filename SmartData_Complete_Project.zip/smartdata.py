import tkinter as tk
from tkinter import filedialog, messagebox
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

selected_file = None

def choose_file():
    global selected_file
    selected_file = filedialog.askopenfilename(
        title="Select CSV or Excel file",
        filetypes=[("CSV files", "*.csv"), ("Excel files", "*.xlsx")]
    )
    if selected_file:
        file_label.config(text=Path(selected_file).name)

def clean_and_report():
    if not selected_file:
        messagebox.showwarning("No file", "Please select a CSV or Excel file first.")
        return

    try:
        if selected_file.lower().endswith(".csv"):
            df = pd.read_csv(selected_file)
        else:
            df = pd.read_excel(selected_file)

        original_rows = len(df)
        original_cols = len(df.columns)

        df = df.dropna(how="all").dropna(axis=1, how="all")
        duplicates_removed = int(df.duplicated().sum())
        df = df.drop_duplicates()

        df.columns = (
            df.columns.astype(str).str.strip().str.lower().str.replace(" ", "_")
        )

        for col in df.select_dtypes(include="object").columns:
            df[col] = df[col].astype(str).str.strip()
            df[col] = df[col].replace(
                {"nan": pd.NA, "": pd.NA, "N/A": pd.NA, "n/a": pd.NA, "NA": pd.NA}
            )

        missing_before = int(df.isna().sum().sum())

        for col in df.select_dtypes(include="number").columns:
            if df[col].isna().any():
                df[col] = df[col].fillna(df[col].median())

        for col in df.select_dtypes(include="object").columns:
            df[col] = df[col].fillna("Unknown")

        missing_after = int(df.isna().sum().sum())

        output_dir = Path("output")
        output_dir.mkdir(exist_ok=True)

        df.to_excel(output_dir / "cleaned_data.xlsx", index=False)

        numeric_cols = df.select_dtypes(include="number").columns.tolist()
        plt.figure(figsize=(9, 5))
        if numeric_cols:
            df[numeric_cols].mean().plot(kind="bar")
            plt.title("Average Values of Numeric Columns")
            plt.ylabel("Average")
            plt.xticks(rotation=30, ha="right")
        else:
            cat_cols = df.select_dtypes(include="object").columns.tolist()
            if cat_cols:
                df[cat_cols[0]].value_counts().head(10).plot(kind="bar")
                plt.title(f"Top Values in {cat_cols[0]}")
                plt.ylabel("Count")
                plt.xticks(rotation=30, ha="right")
        plt.tight_layout()
        plt.savefig(output_dir / "data_summary.png", dpi=150)
        plt.close()

        with open(output_dir / "data_report.txt", "w", encoding="utf-8") as f:
            f.write("SMARTDATA - AUTOMATED DATA CLEANING REPORT\n")
            f.write("=" * 48 + "\n\n")
            f.write(f"Source file: {Path(selected_file).name}\n")
            f.write(f"Original rows: {original_rows}\n")
            f.write(f"Original columns: {original_cols}\n")
            f.write(f"Duplicate rows removed: {duplicates_removed}\n")
            f.write(f"Missing values before cleaning: {missing_before}\n")
            f.write(f"Missing values after cleaning: {missing_after}\n")
            f.write(f"Final rows: {len(df)}\n")
            f.write(f"Final columns: {len(df.columns)}\n\n")
            f.write("Numeric summary:\n")
            f.write(df.select_dtypes(include="number").describe().round(2).to_string())

        messagebox.showinfo(
            "Success",
            "Cleaning completed!\n\nCheck the output folder for the cleaned Excel file, report and chart."
        )
    except Exception as e:
        messagebox.showerror("Error", str(e))

root = tk.Tk()
root.title("SmartData - Data Cleaning & Reporting Automation")
root.geometry("650x420")
root.resizable(False, False)

tk.Label(root, text="SmartData", font=("Arial", 26, "bold")).pack(pady=(35,5))
tk.Label(root, text="Data Cleaning & Reporting Automation", font=("Arial", 14)).pack()
tk.Label(
    root,
    text="Upload a CSV or Excel file and automatically clean, analyze and summarize it.",
    font=("Arial", 11), wraplength=520, justify="center"
).pack(pady=18)

tk.Button(root, text="Choose CSV / Excel File", command=choose_file,
          width=25, height=2).pack(pady=5)
file_label = tk.Label(root, text="No file selected", fg="gray")
file_label.pack(pady=5)

tk.Button(root, text="CLEAN DATA & GENERATE REPORT",
          command=clean_and_report, width=32, height=2).pack(pady=25)

tk.Label(root, text="Python • Pandas • Excel • Matplotlib",
         font=("Arial", 9)).pack(side="bottom", pady=20)

root.mainloop()
